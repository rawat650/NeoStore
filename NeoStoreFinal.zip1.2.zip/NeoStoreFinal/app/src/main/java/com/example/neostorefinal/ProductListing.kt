package com.example.neostorefinal

import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.neostorefinal.api.RetrofitClient
import kotlinx.android.synthetic.main.activity_product_detail_screen.*
import kotlinx.android.synthetic.main.activity_product_listing.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class ProductListing : AppCompatActivity() {
    lateinit var list: MutableList<ProductData>
    lateinit var temporayList: MutableList<ProductData>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_listing)
//        setSupportActionBar(productCategoriesToolBar)
        /*supportActionBar?.setDisplayShowTitleEnabled(false)*/
        supportActionBar?.hide()

        btnProductTollbarBack.setOnClickListener(){
            onBackPressed()
        }

        val getIntent = intent.getStringExtra("CATEGORY_VALUE")

        when (getIntent) {
            "1" -> productToolbarTitle.text = "Tables"
            "2" -> productToolbarTitle.text = "Chairs"
            "3" -> productToolbarTitle.text = "Sofas"
            "4" -> productToolbarTitle.text = "Cupboards"
        }

        temporayList = mutableListOf<ProductData>()
        RetrofitClient.getClient.productList(getIntent!!).enqueue(object : Callback<ProductList?> {
            override fun onResponse(call: Call<ProductList?>, response: Response<ProductList?>) {

                list = mutableListOf<ProductData>()
                for (item in response.body()?.data!!) {
                    list.add(item)
                }
                temporayList.addAll(list)

                val productAdapter = ProductListAdapter(temporayList)
                productRecyclerView.adapter = productAdapter
                productRecyclerView.layoutManager = LinearLayoutManager(
                    this@ProductListing,
                    LinearLayoutManager.VERTICAL, false
                )
                productAdapter.setOnItemClickListerner(object :
                    ProductListAdapter.onItemClickListerner {
                    override fun onItemClick(position: Int) {
                        val id = position.toString()
                        val prodcutItemIntent =
                            Intent(this@ProductListing, ProductDetailScreen::class.java)
                        prodcutItemIntent.putExtra("PRODUCT_ID", id)
                        startActivity(prodcutItemIntent)
                    }
                })

            }

            override fun onFailure(call: Call<ProductList?>, t: Throwable) {
                Log.d(TAG, "onFailure: ${t.message}")
            }
        })
    }
}
