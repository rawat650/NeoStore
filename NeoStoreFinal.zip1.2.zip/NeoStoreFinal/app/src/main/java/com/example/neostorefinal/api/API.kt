package com.example.neostorefinal.api


import com.example.neostorefinal.*
import retrofit2.Call
import retrofit2.http.*

interface API {
    @FormUrlEncoded
    @POST("users/register")
    fun createUser(
        @Field("first_name") first_name : String,
        @Field("last_name") last_name:String,
        @Field("email") email : String,
        @Field("password") password : String,
        @Field("confirm_password") confirm_password:String,
        @Field("gender") gender:String,
        @Field("phone_no") phone_no:Number
    ):Call<DefaultResponse>



    @GET("products/getList?")
    fun productList(
        @Query("product_category_id") product_category_id:String
    ):Call<ProductList>



    @GET("products/getDetail")
    fun productDetail(
        @Query("product_id") product_id: String
    ):Call<ProductDetail>

    @FormUrlEncoded
    @POST("users/login")
    fun loginUser(
        @Field("email") email: String,
        @Field("password") password:String
    ):Call<DefaultResponse>

    @FormUrlEncoded
    @POST("products/setRating")
    fun ratingProduct(
        @Field("product_id") product_id:String,
        @Field("rating") rating:Int?
    ):Call<RatingResponse>

    @FormUrlEncoded
    @POST("addToCart")
    fun addToCart(
        @Header("access_token") access_token:String,
        @Field("product_id") product_id:Int?,
        @Field("quantity") quantity:Int?
    ):Call<AddToCartResponse>


}